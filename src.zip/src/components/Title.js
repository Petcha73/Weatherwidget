import React, { Component } from 'react';

class Title extends Component {

	render(){

		return(

			<div>

			<h1> Netatmo weathermap widget </h1>
			<h3>Display weather datas from big cities in the world!</h3>

			</div>
			
			);
		}

	}

	export default Title;